const express = require('express');
const { db } = require('../database');
const { authenticateToken } = require('../middleware');
const crypto = require('crypto');

const router = express.Router();

// Get Requests (filtered by role)
router.get('/', authenticateToken, (req, res) => {
    const { role, id, section } = req.user;

    if (role === 'student') {
        const requests = db.prepare('SELECT * FROM requests WHERE student_id = ? ORDER BY created_at DESC').all(id);
        res.json(requests);
    } else if (role === 'mentor') {
        const requests = db.prepare('SELECT * FROM requests WHERE section = ? AND status = ? ORDER BY created_at DESC').all(section, 'PENDING_MENTOR');
        res.json(requests);
    } else if (role === 'hod') {
        // HOD sees requests for all their sections that are PENDING_HOD
        const hodSections = db.prepare('SELECT section FROM hod_sections WHERE hod_id = ?').all(id).map(s => s.section);
        
        if (hodSections.length === 0) {
            return res.json([]);
        }

        const placeholders = hodSections.map(() => '?').join(',');
        const requests = db.prepare(`SELECT * FROM requests WHERE section IN (${placeholders}) AND status = ? ORDER BY created_at DESC`).all(...hodSections, 'PENDING_HOD');
        res.json(requests);
    } else {
        res.json([]);
    }
});

// Create Request (Student)
router.post('/', authenticateToken, (req, res) => {
    if (req.user.role !== 'student') return res.sendStatus(403);

    const { roll_number, section, parent_mobile, reason } = req.body;
    const student_name = req.user.username; // Or fetch name from DB if stored differently, here username is fine or we can use the token's name property if we added it?
    // Let's use name from token logic update in middleware or just fetch user details if needed. 
    // Actually the token has { id, username, role, section }.
    // Let's fetch the full user to be safe or rely on client sending valid data? 
    // Better to use backend user data.

    const user = db.prepare('SELECT name FROM users WHERE id = ?').get(req.user.id);

    const stmt = db.prepare(`
        INSERT INTO requests (student_id, student_name, roll_number, section, parent_mobile, reason, status)
        VALUES (?, ?, ?, ?, ?, ?, 'PENDING_MENTOR')
    `);

    stmt.run(req.user.id, user.name, roll_number, section, parent_mobile, reason);
    res.json({ message: 'Request created successfully' });
});

// Approve/Reject Request (Mentor/HOD)
router.post('/:id/action', authenticateToken, (req, res) => {
    const { id } = req.params;
    const { action } = req.body; // 'approve' or 'reject'
    const { role, id: userId } = req.user;

    const request = db.prepare('SELECT * FROM requests WHERE id = ?').get(id);
    if (!request) {
        return res.status(404).json({ message: 'Request not found' });
    }

    if (role === 'mentor') {
        if (request.status !== 'PENDING_MENTOR') {
            return res.status(400).json({ message: 'Invalid status for mentor action' });
        }

        if (action === 'approve') {
            db.prepare("UPDATE requests SET status = 'PENDING_HOD' WHERE id = ?").run(id);
        } else {
            db.prepare("UPDATE requests SET status = 'REJECTED' WHERE id = ?").run(id);
        }
    } else if (role === 'hod') {
        if (request.status !== 'PENDING_HOD') {
            return res.status(400).json({ message: 'Invalid status for HOD action' });
        }

        if (action === 'approve') {
            const qrCode = crypto.randomBytes(16).toString('hex');
            const expiry = Date.now() + 2 * 60 * 60 * 1000; // 2 hours from now
            db.prepare("UPDATE requests SET status = 'APPROVED', qr_code = ?, qr_expiry = ? WHERE id = ?").run(qrCode, expiry, id);
        } else {
            db.prepare("UPDATE requests SET status = 'REJECTED' WHERE id = ?").run(id);
        }
    } else {
        return res.sendStatus(403);
    }

    res.json({ message: 'Action processed' });
});

// Verify QR (Security)
// Verify QR Code (Security)
router.post('/verify-qr', authenticateToken, (req, res) => {
    if (req.user.role !== 'security') return res.sendStatus(403);
    const { qr_code } = req.body;

    const request = db.prepare('SELECT * FROM requests WHERE qr_code = ?').get(qr_code);

    if (!request) {
        return res.json({ valid: false, message: 'Invalid QR Code' });
    }

    if (request.status === 'USED') {
        return res.json({ valid: false, message: 'QR Code Already Used' });
    }

    if (Date.now() > request.qr_expiry) {
        return res.json({ valid: false, message: 'QR Code Expired' });
    }

    if (request.status !== 'APPROVED') {
        return res.json({ valid: false, message: `Request Status: ${request.status}` });
    }

    // Mark as USED immediately upon scan
    db.prepare("UPDATE requests SET status = 'USED' WHERE id = ?").run(request.id);

    // Return extended details for Security Display
    res.json({
        valid: true,
        student: request.student_name,
        section: request.section,
        generated_at: request.created_at,
        exit_time: Date.now() // Return current server time as exit time
    });
});

module.exports = router;
