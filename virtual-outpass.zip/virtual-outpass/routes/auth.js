const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../database');
const { generateToken } = require('../middleware');

const router = express.Router();

// Check User Endpoint (for Autofill)
router.post('/check-user', (req, res) => {
    const { username } = req.body;
    if (!username) return res.status(400).json({ message: 'Username required' });

    const user = db.prepare('SELECT name, role, section FROM users WHERE username = ?').get(username);
    if (user) {
        res.json({ found: true, name: user.name, role: user.role, section: user.section });
    } else {
        res.json({ found: false });
    }
});

router.post('/login', (req, res) => {
    const { username, name, section, role } = req.body;

    if (!username || !name || !section || !role) {
        return res.status(400).json({ message: 'Missing required fields (ID, Name, Section, Role)' });
    }

    const cleanUsername = username.trim();

    // Find User by ID (username) - check if exists regardless of role
    let user = db.prepare('SELECT * FROM users WHERE username = ?').get(cleanUsername);

    if (!user) {
        // AUTO-REGISTRATION for Demo purposes
        // Default password for new users (unused in this flow but required by schema)
        const hashedPassword = bcrypt.hashSync('password123', 10);

        try {
            const stmt = db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)');
            const result = stmt.run(cleanUsername, hashedPassword, role, name, section);

            // Fetch the newly created user
            user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
        } catch (dbErr) {
            return res.status(400).json({ message: 'Username already exists' });
        }

        // For HOD, if they register with a specific section, ensure they can access it.
        // The user.section is already set, logic below handles it.
    } else {
        // User exists - Update Name and Role in case they changed
        db.prepare('UPDATE users SET name = ?, role = ? WHERE id = ?').run(name, role, user.id);
        user.role = role;
    }

    // Section Verification
    let sectionValid = false;
    if (role === 'hod') {
        // HOD can verify against specific assigned sections or if they have 'ALL'
        const allowed = db.prepare('SELECT section FROM hod_sections WHERE hod_id = ?').all(user.id);
        const allowedSections = allowed.map(r => r.section);

        // Check Primary Section OR 'ALL' OR Assigned Sections
        if (user.section === 'ALL' || user.section === section || allowedSections.includes(section)) {
            sectionValid = true;
        }
    } else {
        // Student/Mentor/Security: Must match assigned section
        // If they just registered, it matches. If they existed, we check if they are trying to login to a different section?
        // Actually, if we want to allow them to "switch" sections or correct it, we should update the section too.
        // But for safety, let's assume if they exist, their section is fixed unless we update it.
        // Given the request "add log in with ... particular section", maybe we Update section too?
        // Let's UPDATE the section on login to match input (TRUST INPUT for demo).
        if (user.section !== section) {
            db.prepare('UPDATE users SET section = ? WHERE id = ?').run(section, user.id);
            user.section = section;
        }
        sectionValid = true;
    }

    if (!sectionValid) {
        // This case might be rare now if we auto-update, but relevant for HOD sophisticated logic
        return res.status(401).json({ message: `Invalid Section. Allowed: ${user.section}` });
    }

    // Ensure HOD has section in hod_sections table (for new HODs)
    if (role === 'hod') {
        const exists = db.prepare('SELECT * FROM hod_sections WHERE hod_id = ? AND section = ?').get(user.id, section);
        if (!exists) {
            db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(user.id, section);
        }
    }

    // Login Success
    const token = generateToken({ ...user, name });
    res.json({ token, role: user.role, name: name, section: user.section });
});

module.exports = router;
