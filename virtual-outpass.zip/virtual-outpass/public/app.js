const API_URL = `http://${window.location.hostname}:3000/api`;

// --- Auth Handling ---
function checkAuth() {
    const token = localStorage.getItem('token');
    if (!token && window.location.pathname !== '/index.html' && window.location.pathname !== '/') {
        window.location.href = '/index.html';
    }
    return token;
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('username');
    window.location.href = '/index.html';
}

// --- Login & Role Handling ---
if (document.querySelector('.role-grid')) {
    // Card Click Handlers - Show Login Section
    document.querySelectorAll('.role-card').forEach(card => {
        card.addEventListener('click', () => {
            const currentRole = card.dataset.role;
            const loginSection = document.getElementById('login-section');
            const roleGrid = document.querySelector('.role-selection-container');

            document.querySelector('main > .role-selection-container').style.display = 'none';

            // Set Form Details
            document.getElementById('modal-role-title').textContent = `${currentRole.charAt(0).toUpperCase() + currentRole.slice(1)} Login`;
            document.getElementById('login-role').value = currentRole;

            // Autofill Logic
            const idInput = document.getElementById('login-id');
            const nameInput = document.getElementById('login-name');
            const sectionSelect = document.getElementById('login-section');

            const autofill = async () => {
                const username = idInput.value.trim();
                // If empty or very short, don't trigger unless explicit blur/change
                if (!username) return;

                try {
                    const res = await fetch(`${API_URL}/auth/check-user`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ username })
                    });
                    const data = await res.json();

                    if (data.found) {
                        nameInput.value = data.name;
                        nameInput.readOnly = true;
                        if (data.section && data.section !== 'ALL') {
                            sectionSelect.value = data.section;
                        }
                    } else {
                        // Only clear/editable if we previously found someone or are in a fresh state
                        // Don't aggressively clear while typing if not found yet (wait for full ID)
                        // But if nameInput was set to readonly, we must unlock it
                        if (nameInput.readOnly) {
                            nameInput.readOnly = false;
                            nameInput.value = '';
                        }
                    }
                } catch (err) {
                    console.error('Autofill error:', err);
                }
            };

            // Remove old listeners to prevent duplicates if card clicked multiple times (though page reload clears it usually)
            // But here we are SPA-ish. Cloning node is a quick hack to clear listeners or just rely on idempotency.
            // Let's just add them.
            idInput.addEventListener('change', autofill);
            idInput.addEventListener('blur', autofill);
            idInput.addEventListener('input', () => {
                // Trigger autofill on input only if length is sufficient to likely be an ID
                if (idInput.value.length >= 2) autofill();
            });


            // Reset Form & Error
            document.getElementById('login-form').reset();
            document.getElementById('login-error').style.display = 'none';

            // Show Login Section
            loginSection.style.display = 'block';
        });
    });

    // Back Button Handler
    document.getElementById('back-btn').addEventListener('click', () => {
        document.getElementById('login-section').style.display = 'none';
        document.querySelector('main > .role-selection-container').style.display = 'block';
    });

    // Handle Form Submit
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorP = document.getElementById('login-error');
        errorP.style.display = 'none';

        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        try {
            console.log('Login attempt with data:', data);

            const res = await fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await res.json();

            if (res.ok) {
                localStorage.setItem('token', result.token);
                localStorage.setItem('role', result.role);
                localStorage.setItem('username', result.name); // Using Name for display
                window.location.href = '/dashboard.html';
            } else {
                errorP.textContent = result.message || 'Login failed';
                errorP.style.display = 'block';
            }
        } catch (err) {
            console.error('Login error:', err);
            errorP.textContent = `Network error: ${err.message}. Make sure server is running at ${API_URL}`;
            errorP.style.display = 'block';
        }
    });
}


// --- Dashboard ---
if (document.getElementById('dashboard-container')) {
    const token = checkAuth();
    const role = localStorage.getItem('role');
    const username = localStorage.getItem('username');

    document.getElementById('user-name').textContent = `${username} (${role})`;
    document.getElementById('logout-btn').addEventListener('click', logout);

    // Render Role Specific View
    const content = document.getElementById('dashboard-content');

    if (role === 'student') {
        renderStudentView(content);
    } else if (role === 'mentor' || role === 'hod') {
        renderApproverView(content, role);
    } else if (role === 'security') {
        renderSecurityView(content);
    }

    // Polling for updates (simple way to keep UI fresh)
    if (role !== 'security') {
        fetchRequests();
        setInterval(fetchRequests, 5000);
    }
}

async function fetchRequests() {
    const role = localStorage.getItem('role');
    if (role === 'security') return; // Security doesn't fetch list

    try {
        const res = await fetch(`${API_URL}/requests`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (res.status === 401 || res.status === 403) {
            logout();
            return;
        }

        const requests = await res.json();
        const listContainer = document.getElementById('requests-list');
        if (listContainer) {
            listContainer.innerHTML = requests.map(req => createRequestCard(req, role)).join('');

            // Re-attach event listeners for buttons
            document.querySelectorAll('.action-btn').forEach(btn => {
                btn.addEventListener('click', handleAction);
            });
        }
    } catch (err) {
        console.error('Fetch error:', err);
    }
}

function renderStudentView(container) {
    container.innerHTML = `
        <div class="card">
            <h3>New Outpass Request</h3>
            <form id="request-form">
                <div class="form-group">
                    <label>Roll Number</label>
                    <input type="text" name="roll_number" required>
                </div>
                <div class="form-group">
                    <label>Section</label>
                    <select name="section" required>
                        <option value="CSE-A">CSE-A</option>
                        <option value="CSE-B">CSE-B</option>
                        <option value="CSE-C">CSE-C</option>
                        <option value="CSD">CSD</option>
                        <option value="CSAI">CSAI</option>
                        <option value="CSM">CSM</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Parent Mobile</label>
                    <input type="tel" name="parent_mobile" required>
                </div>
                <div class="form-group">
                    <label>Reason</label>
                    <textarea name="reason" rows="3" required></textarea>
                </div>
                <button type="submit">Submit Request</button>
            </form>
        </div>
        <h3>My Requests</h3>
        <div id="requests-list">Loading...</div>
    `;

    document.getElementById('request-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());

        try {
            const res = await fetch(`${API_URL}/requests`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(data)
            });
            if (res.ok) {
                e.target.reset();
                showToast('Request submitted');
                fetchRequests();
            } else {
                showToast('Failed to submit request');
            }
        } catch (err) {
            console.error(err);
        }
    });
}

function renderApproverView(container, role) {
    container.innerHTML = `
        <h3>Pending Requests</h3>
        <div id="requests-list">Loading...</div>
    `;
}

function renderSecurityView(container) {
    container.innerHTML = `
        <div class="card" style="text-align: center;">
            <h3>Scan Student QR Code</h3>
            <div id="reader"></div>
            <div id="scan-result" style="margin-top: 1rem; font-weight: bold;"></div>
        </div>
    `;

    // Initialize HTML5-QRCode
    // We need to load the library script in HTML first
    setTimeout(() => {
        const html5QrcodeScanner = new Html5QrcodeScanner(
            "reader", { fps: 10, qrbox: 250 });
        html5QrcodeScanner.render(onScanSuccess);
    }, 500);
}

async function onScanSuccess(decodedText, decodedResult) {
    // Prevent multiple calls
    if (window.isScanning) return;
    window.isScanning = true;

    try {
        const res = await fetch(`${API_URL}/requests/verify-qr`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ qr_code: decodedText })
        });
        const data = await res.json();

        const resultDiv = document.getElementById('scan-result');
        if (data.valid) {
            // Show detailed exit info
            resultDiv.innerHTML = `
                <div style="background-color: #d4edda; color: #155724; padding: 1rem; border-radius: 5px; margin-top: 1rem;">
                    <h2 style="margin: 0;">✔ EXIT AUTHORIZED</h2>
                    <p style="font-size: 1.2rem; margin: 0.5rem 0;"><strong>Name:</strong> ${data.student}</p>
                    <p style="font-size: 1.2rem; margin: 0.5rem 0;"><strong>Section:</strong> ${data.section}</p>
                    <p style="font-size: 1rem; margin: 0;"><strong>Time:</strong> ${new Date(data.exit_time || Date.now()).toLocaleString()}</p>
                </div>
            `;
            new Audio('https://www.soundjay.com/buttons/sounds/button-3.mp3').play().catch(() => { });
        } else {
            resultDiv.innerHTML = `
                <div style="background-color: #f8d7da; color: #721c24; padding: 1rem; border-radius: 5px; margin-top: 1rem;">
                    <h2 style="margin: 0;">✘ DENIED</h2>
                    <p style="font-size: 1.2rem;">${data.message}</p>
                </div>
            `;
            new Audio('https://www.soundjay.com/buttons/sounds/beep-02.mp3').play().catch(() => { });
        }
    } catch (err) {
        console.error(err);
    }

    setTimeout(() => { window.isScanning = false; }, 3000);
}

function createRequestCard(req, userRole) {
    let actions = '';
    let qrDisplay = '';

    // Action Buttons for Mentor/HOD
    if (userRole === 'mentor' && req.status === 'PENDING_MENTOR') {
        const parentPhone = `tel:${req.parent_mobile}`;
        actions = `
            <div style="margin-bottom: 0.5rem; text-align: center;">
                 <a href="${parentPhone}" class="contact-link" style="display:block; background:#f0f9ff; border-color:#0ea5e9; color:#0369a1;">📞 Call Parent (${req.parent_mobile})</a>
            </div>
            <div class="action-buttons">
                <button class="action-btn btn-approve" data-id="${req.id}" data-action="approve">Forward to HOD</button>
                <button class="action-btn btn-reject" data-id="${req.id}" data-action="reject">Reject</button>
            </div>
        `;
    } else if (userRole === 'hod' && req.status === 'PENDING_HOD') {
        actions = `
            <div class="action-buttons">
                <a href="tel:${req.parent_mobile}" class="contact-link" style="display:block; background:#f0f9ff; border-color:#0ea5e9; color:#0369a1; text-align:center; padding: 0.5rem; margin-bottom: 0.5rem; border-radius: 4px; border: 1px solid;">📞 Call Parent (${req.parent_mobile})</a>
                <button class="action-btn btn-approve" data-id="${req.id}" data-action="approve">Approve & Generate QR</button>
                <button class="action-btn btn-reject" data-id="${req.id}" data-action="reject">Reject</button>
            </div>
        `;
    }

    // Call Buttons for Student/Others (if needed, or just status)
    let contactLinks = '';
    // Demo phone number - in real app would come from DB
    const demoPhone = "tel:9876543210";

    if (req.status === 'PENDING_MENTOR') {
        // Student waiting for mentor
        contactLinks = `<a href="${demoPhone}" class="contact-link" style="display:block; margin-top:0.5rem; color:var(--primary);">📞 Call Mentor</a>`;
    } else if (req.status === 'PENDING_HOD') {
        // Student waiting for HOD
        // contactLinks = `<a href="${demoPhone}" class="contact-link" style="display:block; margin-top:0.5rem; color:var(--primary);">📞 Call HOD</a>`;
    }

    // QR Code for Student
    if (req.status === 'APPROVED' && req.qr_code && userRole === 'student') {
        const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${req.qr_code}`;
        qrDisplay = `
            <div class="qr-display">
                <img src="${qrUrl}" alt="QR Code">
                <p>Show this to security</p>
            </div>
        `;
    }

    return `
        <div class="card">
            <div style="display:flex; justify-content:space-between;">
                <strong>${req.student_name} (${req.roll_number})</strong>
                <span class="status-badge status-${req.status}">${req.status.replace('_', ' ')}</span>
            </div>
            <p><strong>Reason:</strong> ${req.reason}</p>
            <p><small>Created: ${new Date(req.created_at).toLocaleString()}</small></p>
            ${contactLinks}
            ${actions}
            ${qrDisplay}
        </div>
    `;
}

async function handleAction(e) {
    const id = e.target.dataset.id;
    const action = e.target.dataset.action;

    try {
        const res = await fetch(`${API_URL}/requests/${id}/action`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ action })
        });
        if (res.ok) {
            showToast(`Request ${action}ed`);
            fetchRequests(); // Refresh list
        } else {
            showToast('Action failed');
        }
    } catch (err) {
        console.error(err);
    }
}

function showToast(msg) {
    const x = document.getElementById("toast");
    x.textContent = msg;
    x.className = "show";
    setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
}
