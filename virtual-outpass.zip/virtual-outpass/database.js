const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const db = new Database('aegis.db');

function initDb() {
    // Users Table
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('student', 'mentor', 'hod', 'security')),
            name TEXT NOT NULL,
            section TEXT -- For Students (their section) and Mentors (assigned section)
        )
    `);

    // HOD Sections Table (HODs manage multiple sections)
    db.exec(`
        CREATE TABLE IF NOT EXISTS hod_sections (
            hod_id INTEGER,
            section TEXT,
            FOREIGN KEY(hod_id) REFERENCES users(id)
        )
    `);

    // Requests Table
    db.exec(`
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            student_name TEXT NOT NULL,
            roll_number TEXT NOT NULL,
            section TEXT NOT NULL,
            parent_mobile TEXT NOT NULL,
            reason TEXT NOT NULL,
            status TEXT DEFAULT 'PENDING_MENTOR', -- PENDING_MENTOR, PENDING_HOD, APPROVED, REJECTED, USED
            qr_code TEXT UNIQUE,
            qr_expiry DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(student_id) REFERENCES users(id)
        )
    `);

    seedUsers();
}

function seedUsers() {
    const check = db.prepare('SELECT count(*) as count FROM users').get();
    if (check.count > 0) return;
    try {
        const salt = bcrypt.genSaltSync(10);
        const password = bcrypt.hashSync('password123', salt);

        // Students
        db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('studentA', password, 'student', 'Alice Student', 'CSE-A');
        db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('studentB', password, 'student', 'Bob Student', 'CSE-B');

        // Mentors
        db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('mentor_cse_a', password, 'mentor', 'Prof. Alan (CSE-A)', 'CSE-A');
        db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('mentor_csd', password, 'mentor', 'Prof. Turing (CSD)', 'CSD');

        // HOD 001: CSD, CSAI - CH.RAMA MOHAN
        const h1 = db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('001', password, 'hod', 'CH.RAMA MOHAN', 'ALL');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h1.lastInsertRowid, 'CSD');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h1.lastInsertRowid, 'CSAI');

        // HOD 002: CSE-A, B, C - P.PENCHALAIAH
        const h2 = db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('002', password, 'hod', 'P.PENCHALAIAH', 'ALL');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h2.lastInsertRowid, 'CSE-A');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h2.lastInsertRowid, 'CSE-B');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h2.lastInsertRowid, 'CSE-C');

        // HOD 003: CSM - C.RAJENDRA
        const h3 = db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('003', password, 'hod', 'C.RAJENDRA', 'ALL');
        db.prepare('INSERT INTO hod_sections (hod_id, section) VALUES (?, ?)').run(h3.lastInsertRowid, 'CSM');

        // Security
        db.prepare('INSERT INTO users (username, password, role, name, section) VALUES (?, ?, ?, ?, ?)').run('security', password, 'security', 'Chief Security', 'GATE');
    } catch (err) {
    }
}

module.exports = { db, initDb };
