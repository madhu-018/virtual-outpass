const jwt = require('jsonwebtoken');

const SECRET_KEY = 'super_secret_key_for_hackathon';

function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'Unauthorized' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ message: 'Forbidden' });
        req.user = user;
        next();
    });
}

function generateToken(user) {
    return jwt.sign({ id: user.id, username: user.username, role: user.role, section: user.section }, SECRET_KEY, { expiresIn: '24h' });
}

module.exports = { authenticateToken, generateToken };
