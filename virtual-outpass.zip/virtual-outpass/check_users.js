const Database = require('better-sqlite3');
const db = new Database('aegis.db');

try {
    const users = db.prepare('SELECT id, username, role, name, section FROM users').all();
} catch (err) {
}
