const { db } = require('./database');

const rows = db.prepare(`
    SELECT u.id, u.username, u.name, hs.section 
    FROM users u 
    JOIN hod_sections hs ON u.id = hs.hod_id 
    WHERE hs.section IN ('CSD', 'CSAI')
`).all();

if (rows.length > 0) {
    const uniqueIDs = [...new Set(rows.map(r => r.id))];
    if (uniqueIDs.length === 1) {
    } else {
    }
} else {
}
